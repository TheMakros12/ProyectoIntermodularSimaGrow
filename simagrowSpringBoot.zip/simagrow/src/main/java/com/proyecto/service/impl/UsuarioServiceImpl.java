package com.proyecto.service.impl;

import com.proyecto.model.Simagrow_Usuario;
import com.proyecto.model.dto.*;
import com.proyecto.repository.IUsuarioRepository;
import com.proyecto.service.IUsuarioService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioServiceImpl implements IUsuarioService {

    @Autowired
    private IUsuarioRepository repo;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public UsuarioResponseDTO crearUsuario(UsuarioRequestDTO requestDTO) {
        Simagrow_Usuario simagrowusuario = new Simagrow_Usuario();

        return getUsuarioResponseDTO(requestDTO, simagrowusuario);
    }

    @Override
    public List<UsuarioResponseDTO> obtenerUsuarios() {
        List<Simagrow_Usuario> simagrowusuarios = repo.findAll();
        return simagrowusuarios.stream()
                .map(usuario -> modelMapper.map(usuario, UsuarioResponseDTO.class))
                .toList();
    }

    @Override
    public UsuarioResponseDTO actualizarUsuario(Integer id, UsuarioRequestDTO requestDTO) throws Exception {
        Simagrow_Usuario simagrowusuario = repo.findById(id)
                .orElseThrow(() -> new Exception(""));

        return getUsuarioResponseDTO(requestDTO, simagrowusuario);
    }

    private UsuarioResponseDTO getUsuarioResponseDTO(UsuarioRequestDTO requestDTO, Simagrow_Usuario simagrowusuario) {
        simagrowusuario.setNombre(requestDTO.getNombre());
        simagrowusuario.setApellidos(requestDTO.getApellidos());
        simagrowusuario.setCorreo(requestDTO.getCorreo());
        simagrowusuario.setContrasena(requestDTO.getContrasena());
        simagrowusuario.setAdmin(false);
        simagrowusuario.setNif(requestDTO.getNif());
        simagrowusuario.setCreditos(requestDTO.getCreditos());

        repo.save(simagrowusuario);

        return modelMapper.map(simagrowusuario, UsuarioResponseDTO.class);
    }

    @Override
    public void eliminarUsuario(Integer id) {

        repo.deleteById(id);
    }

    @Override
    public Simagrow_Usuario buscarPorId(Integer id) {
        return repo.findById(id).orElseThrow();
    }

    @Override
    public LoginResponseDTO loginUsuario(LoginRequestDTO requestDTO) throws Exception {
        Simagrow_Usuario simagrowusuario = repo.findByCorreo(requestDTO.getCorreo());

        if (simagrowusuario == null) throw new Exception("no_existe_usuario");

        if (!requestDTO.getContrasena().equals(simagrowusuario.getContrasena()))
            throw new Exception("contrasenya_incorrecta");

        simagrowusuario.setCorreo(requestDTO.getCorreo());
        simagrowusuario.setContrasena(requestDTO.getContrasena());

        if (!simagrowusuario.isAdmin())
            throw new Exception("no_es_admin");

        repo.save(simagrowusuario);
        return modelMapper.map(simagrowusuario, LoginResponseDTO.class);

    }

    @Override
    public LoginResponseDTO loginUsuarioApp(LoginAppRequestDTO requestDTO) throws Exception {
        Simagrow_Usuario simagrowusuario = repo.findByNif(requestDTO.getNif());

        if (simagrowusuario == null) throw new Exception("no_existe_usuario");

        if (!requestDTO.getContrasena().equals(simagrowusuario.getContrasena()))
            throw new Exception("contrasenya_incorrecta");

        simagrowusuario.setNif(requestDTO.getNif());
        simagrowusuario.setContrasena(requestDTO.getContrasena());

        repo.save(simagrowusuario);
        return modelMapper.map(simagrowusuario, LoginResponseDTO.class);
    }

    @Override
    public UsuarioResponseDTO modificarBooleano(Integer id) throws Exception {
        Simagrow_Usuario simagrowusuario = repo.findById(id)
                .orElseThrow(() -> new Exception("usuario_no_existe"));

        boolean esAdmin = simagrowusuario.isAdmin();
        simagrowusuario.setAdmin(!esAdmin);

        return modelMapper.map(simagrowusuario, UsuarioResponseDTO.class);
    }
}
