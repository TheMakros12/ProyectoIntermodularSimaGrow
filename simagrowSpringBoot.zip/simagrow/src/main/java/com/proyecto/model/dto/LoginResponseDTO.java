package com.proyecto.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginResponseDTO {

    private Integer id;

    private String nombre;

    private String apellidos;

    private String correo;

    private Boolean admin;

    private String nif;

    private Integer creditos;
}