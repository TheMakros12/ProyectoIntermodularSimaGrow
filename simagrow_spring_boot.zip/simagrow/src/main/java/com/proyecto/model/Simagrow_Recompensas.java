package com.proyecto.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Simagrow_Recompensas {

    @Id
    private Integer id;

    @Column
    private String nombre;

    @Column
    private double tokens;

    @Column
    private String tipo;

    @Column
    private byte[] imagen;



}
