package com.proyecto.model.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RecompensaRequestDTO {

    @NotBlank
    private String nombre;

    @NotNull
    private double tokens;

    @NotBlank
    private String tipo;

    private byte[] imagen;

}
