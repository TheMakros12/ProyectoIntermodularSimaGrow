package com.proyecto.model.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginAppRequestDTO {

    @NotBlank
    private String nif;

    @NotBlank
    private String contrasena;

}
