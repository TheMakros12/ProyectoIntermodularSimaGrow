package com.proyecto.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RecompensaResponseDTO {

    private Integer id;

    private String nombre;

    private double tokens;

    private String tipo;

    private byte[] imagen;

}
