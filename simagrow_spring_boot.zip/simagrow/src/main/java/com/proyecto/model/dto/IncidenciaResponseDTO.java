package com.proyecto.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IncidenciaResponseDTO {

    private Integer id;

    private String titulo;

    private String descripcion;

    private boolean isResuelta;

    private Integer usuarioId;

    private String usuarioNombre;

    private String usuarioApellidos;

    private String espacioUbicacion;

    private LocalDate fechaIncidencia;


}
