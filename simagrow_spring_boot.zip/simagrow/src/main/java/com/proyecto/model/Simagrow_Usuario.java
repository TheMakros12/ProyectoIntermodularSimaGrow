package com.proyecto.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Simagrow_Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column
    private String nif;

    @Column
    private String nombre;

    @Column
    private String apellidos;

    @Column
    private LocalDate fechaNacimiento;

    @Column
    private String correo;

    @Column
    private String contrasena;

    @Column
    private Integer creditos;

    @Column
    private boolean admin;
}
