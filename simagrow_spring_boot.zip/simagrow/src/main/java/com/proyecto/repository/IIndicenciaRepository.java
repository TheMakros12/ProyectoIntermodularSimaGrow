package com.proyecto.repository;

import com.proyecto.model.Simagrow_Incidencia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IIndicenciaRepository extends JpaRepository<Simagrow_Incidencia, Integer> {
}
