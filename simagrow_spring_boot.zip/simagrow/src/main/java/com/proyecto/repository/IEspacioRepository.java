package com.proyecto.repository;

import com.proyecto.model.Simagrow_Espacio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IEspacioRepository extends JpaRepository<Simagrow_Espacio, Integer> {
}
