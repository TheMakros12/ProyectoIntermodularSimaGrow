package com.proyecto.repository;

import com.proyecto.model.Simagrow_Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IUsuarioRepository extends JpaRepository<Simagrow_Usuario, Integer> {

    Simagrow_Usuario findByCorreo(String email);

    Simagrow_Usuario findByNif(String nif);
}
