package com.proyecto.repository;

import com.proyecto.model.Simagrow_Recompensas;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IRecompensaRepository extends JpaRepository<Simagrow_Recompensas, Integer> {
}
