package com.proyecto.service;

import com.proyecto.model.Simagrow_Espacio;

import java.util.List;

public interface IEspacioService {

    Simagrow_Espacio crearEspacio(Simagrow_Espacio simagrowEspacio);

    List<Simagrow_Espacio> obtenerEspacios();

    Simagrow_Espacio modificarEspacio(Simagrow_Espacio simagrowEspacio);

    void eliminarEspacio(Integer id);

    Simagrow_Espacio buscarEspacio(Integer id);
}
