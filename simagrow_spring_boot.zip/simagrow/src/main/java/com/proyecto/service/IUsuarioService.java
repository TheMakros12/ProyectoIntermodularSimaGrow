package com.proyecto.service;

import com.proyecto.model.Simagrow_Usuario;
import com.proyecto.model.dto.*;

import java.util.List;

public interface IUsuarioService {

    UsuarioResponseDTO crearUsuario(UsuarioRequestDTO requestDTO);

    List<UsuarioResponseDTO> obtenerUsuarios();

    UsuarioResponseDTO actualizarUsuario(Integer id, UsuarioRequestDTO requestDTO) throws Exception;

    void eliminarUsuario(Integer id);

    Simagrow_Usuario buscarPorId(Integer id);

    LoginResponseDTO loginUsuario(LoginRequestDTO requestDTO) throws Exception;

    LoginResponseDTO loginUsuarioApp(LoginAppRequestDTO requestDTO) throws Exception;

    UsuarioResponseDTO modificarBooleano(Integer id) throws Exception;
}
