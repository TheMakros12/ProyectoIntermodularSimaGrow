package com.proyecto.service.impl;

import com.proyecto.model.Simagrow_Incidencia;
import com.proyecto.model.Simagrow_Recompensas;
import com.proyecto.model.dto.RecompensaRequestDTO;
import com.proyecto.model.dto.RecompensaResponseDTO;
import com.proyecto.repository.IRecompensaRepository;
import com.proyecto.service.IIncidenciaService;
import com.proyecto.service.IRecompensaService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecompensaServiceImpl implements IRecompensaService {

    @Autowired
    private IRecompensaRepository repo;

    @Autowired
    private IIncidenciaService incidenciaService;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public RecompensaResponseDTO crearRecompensa(RecompensaRequestDTO requestDTO) {
        Simagrow_Recompensas simagrowRecompensa = new Simagrow_Recompensas();

        return getRecompensaResponseDTO(requestDTO, simagrowRecompensa);
    }

    @Override
    public List<RecompensaResponseDTO> listaRecompensas() {
        List<Simagrow_Recompensas> simagrowRecompensas = repo.findAll();

        return simagrowRecompensas.stream()
                .map(simagrowRecompensa -> modelMapper.map(simagrowRecompensa, RecompensaResponseDTO.class))
                .toList();
    }

    @Override
    public RecompensaResponseDTO modificarRecompensa(Integer id, RecompensaRequestDTO requestDTO) throws Exception {
        Simagrow_Recompensas simagrowRecompensa = repo.findById(id).orElseThrow(() -> new Exception(""));

        return getRecompensaResponseDTO(requestDTO, simagrowRecompensa);
    }

    @Override
    public void eliminarRecompensa(Integer id) {
        if (repo.existsById(id))
            repo.deleteById(id);
    }

    private RecompensaResponseDTO getRecompensaResponseDTO(RecompensaRequestDTO requestDTO, Simagrow_Recompensas simagrowRecompensa) {
        simagrowRecompensa.setNombre(requestDTO.getNombre());
        simagrowRecompensa.setTokens(requestDTO.getTokens());
        simagrowRecompensa.setTipo(requestDTO.getTipo());
        simagrowRecompensa.setImagen(requestDTO.getImagen());

        repo.save(simagrowRecompensa);

        return modelMapper.map(simagrowRecompensa, RecompensaResponseDTO.class);
    }
}
