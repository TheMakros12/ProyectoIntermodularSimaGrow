package com.proyecto.service.impl;

import com.proyecto.model.Simagrow_Espacio;
import com.proyecto.model.Simagrow_Incidencia;
import com.proyecto.model.Simagrow_Usuario;
import com.proyecto.model.dto.IncidenciaRequestDTO;
import com.proyecto.model.dto.IncidenciaResponseDTO;
import com.proyecto.repository.IIndicenciaRepository;
import com.proyecto.service.IEspacioService;
import com.proyecto.service.IIncidenciaService;
import com.proyecto.service.IUsuarioService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IncidenciaServiceImpl implements IIncidenciaService {

    @Autowired
    private IIndicenciaRepository repo;

    @Autowired
    private IUsuarioService usuarioService;

    @Autowired
    private IEspacioService espacioService;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public IncidenciaResponseDTO crearIncidencia(IncidenciaRequestDTO requestDTO) {
        Simagrow_Incidencia simagrowIncidencia = new Simagrow_Incidencia();

        return getIncidenciaResponseDTO(requestDTO, simagrowIncidencia);
    }

    @Override
    public List<IncidenciaResponseDTO> obtenerIncidencias() {
        List<Simagrow_Incidencia> simagrowIncidencias = repo.findAll();

        return simagrowIncidencias.stream()
                .map(incidencia -> modelMapper.map(incidencia, IncidenciaResponseDTO.class))
                .toList();
    }

    @Override
    public IncidenciaResponseDTO modificarIncidencia(Integer id, IncidenciaRequestDTO requestDTO) throws Exception {
        Simagrow_Incidencia simagrowIncidencia = repo.findById(id)
                .orElseThrow(() -> new Exception("incidencia_no_encontrada"));

        return getIncidenciaResponseDTO(requestDTO, simagrowIncidencia);
    }

    @Override
    public void eliminarIndicencia(Integer id) {
        if (repo.existsById(id))
            repo.deleteById(id);
    }

    @Override
    public Simagrow_Incidencia buscarPorId(Integer id) {
        return repo.findById(id).orElseThrow();
    }

    @Override
    public IncidenciaResponseDTO cambiarEstado(Integer id) throws Exception {
        Simagrow_Incidencia simagrowIncidencia = repo.findById(id)
                .orElseThrow(() -> new Exception("incidencia_no_existe"));

        simagrowIncidencia.setResuelta(!simagrowIncidencia.isResuelta());

        repo.save(simagrowIncidencia);

        return modelMapper.map(simagrowIncidencia, IncidenciaResponseDTO.class);
    }

    private IncidenciaResponseDTO getIncidenciaResponseDTO(IncidenciaRequestDTO requestDTO, Simagrow_Incidencia simagrowIncidencia) {
        simagrowIncidencia.setTitulo(requestDTO.getTitulo());
        simagrowIncidencia.setDescripcion(requestDTO.getDescripcion());

        Simagrow_Usuario simagrowusuario = usuarioService.buscarPorId(requestDTO.getUsuarioId());
        Simagrow_Espacio simagrowEspacio = espacioService.buscarEspacio(requestDTO.getEspacioId());

        simagrowIncidencia.setSimagrowUsuario(simagrowusuario);
        simagrowIncidencia.setSimagrowEspacio(simagrowEspacio);
        simagrowIncidencia.setResuelta(false);
        simagrowIncidencia.setFechaIncidencia(requestDTO.getFechaIncidencia());

        repo.save(simagrowIncidencia);

        IncidenciaResponseDTO responseDTO = modelMapper.map(simagrowIncidencia, IncidenciaResponseDTO.class);
        responseDTO.setUsuarioNombre(simagrowusuario.getNombre());
        responseDTO.setUsuarioApellidos(simagrowusuario.getApellidos());
        responseDTO.setEspacioUbicacion(simagrowEspacio.getUbicacion());

        return responseDTO;
    }

}
