package com.proyecto.service.impl;

import com.proyecto.model.Simagrow_Espacio;
import com.proyecto.repository.IEspacioRepository;
import com.proyecto.service.IEspacioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EspacioServiceImpl implements IEspacioService {

    @Autowired
    private IEspacioRepository repo;

    @Override
    public Simagrow_Espacio crearEspacio(Simagrow_Espacio simagrowEspacio) {
        return repo.save(simagrowEspacio);
    }

    @Override
    public List<Simagrow_Espacio> obtenerEspacios() {
        return repo.findAll();
    }

    @Override
    public Simagrow_Espacio modificarEspacio(Simagrow_Espacio simagrowEspacio) {
        return repo.save(simagrowEspacio);
    }

    @Override
    public void eliminarEspacio(Integer id) {
        repo.deleteById(id);
    }

    @Override
    public Simagrow_Espacio buscarEspacio(Integer id) {
        return repo.findById(id).orElseThrow();
    }
}
