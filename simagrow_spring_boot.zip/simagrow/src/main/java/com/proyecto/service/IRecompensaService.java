package com.proyecto.service;

import com.proyecto.model.dto.RecompensaRequestDTO;
import com.proyecto.model.dto.RecompensaResponseDTO;

import java.util.List;

public interface IRecompensaService {

    RecompensaResponseDTO crearRecompensa(RecompensaRequestDTO requestDTO);

    List<RecompensaResponseDTO> listaRecompensas();

    RecompensaResponseDTO modificarRecompensa(Integer id, RecompensaRequestDTO requestDTO) throws Exception;

    void eliminarRecompensa(Integer id);
}
