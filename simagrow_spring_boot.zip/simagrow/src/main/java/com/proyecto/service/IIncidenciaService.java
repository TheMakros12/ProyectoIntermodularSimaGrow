package com.proyecto.service;

import com.proyecto.model.Simagrow_Incidencia;
import com.proyecto.model.dto.IncidenciaRequestDTO;
import com.proyecto.model.dto.IncidenciaResponseDTO;

import java.util.List;

public interface IIncidenciaService {

    IncidenciaResponseDTO crearIncidencia(IncidenciaRequestDTO requestDTO);

    List<IncidenciaResponseDTO> obtenerIncidencias();

    IncidenciaResponseDTO modificarIncidencia(Integer id, IncidenciaRequestDTO requestDTO) throws Exception;

    void eliminarIndicencia(Integer id);

    Simagrow_Incidencia buscarPorId(Integer id);

    IncidenciaResponseDTO cambiarEstado(Integer id) throws Exception;
}
