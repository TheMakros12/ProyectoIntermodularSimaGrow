package com.proyecto.controller;

import com.proyecto.model.dto.RecompensaRequestDTO;
import com.proyecto.model.dto.RecompensaResponseDTO;
import com.proyecto.service.IRecompensaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/recompenses")
public class RecompensaController {

    @Autowired
    private IRecompensaService service;

    @PostMapping
    public ResponseEntity<RecompensaResponseDTO> crearRecompensa(@RequestBody RecompensaRequestDTO requestDTO) {
        RecompensaResponseDTO responseDTO = service.crearRecompensa(requestDTO);

        return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<RecompensaResponseDTO>> listaRecompensas() {
        List<RecompensaResponseDTO> responseDTOS = service.listaRecompensas();

        return new ResponseEntity<>(responseDTOS, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<RecompensaResponseDTO> modificarRecompensa(@PathVariable Integer id, @RequestBody RecompensaRequestDTO requestDTO) {
        try {
            RecompensaResponseDTO responseDTO = service.modificarRecompensa(id, requestDTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);

        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarRecompensa(@PathVariable Integer id) {
        service.eliminarRecompensa(id);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
