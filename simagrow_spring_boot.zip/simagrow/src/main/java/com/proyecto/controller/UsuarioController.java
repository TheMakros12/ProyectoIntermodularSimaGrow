package com.proyecto.controller;

import com.proyecto.model.dto.*;
import com.proyecto.service.IUsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UsuarioController {

    @Autowired
    private IUsuarioService service;

    @PostMapping
    public ResponseEntity<UsuarioResponseDTO> crearUsuario(@Valid @RequestBody UsuarioRequestDTO requestDTO) {
        UsuarioResponseDTO responseDTO = service.crearUsuario(requestDTO);

        return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponseDTO> login(@RequestBody LoginRequestDTO requestDTO) {
        try {
            LoginResponseDTO response = service.loginUsuario(requestDTO);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            if (e.getMessage().equals("no_existe_usuario"))
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);

            if (e.getMessage().equals("no_es_admin"))
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);

            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

    }

    @PostMapping("/loginApp")
    public ResponseEntity<LoginResponseDTO> loginApp(@RequestBody LoginAppRequestDTO requestDTO) {
        try {
            LoginResponseDTO response = service.loginUsuarioApp(requestDTO);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            if (e.getMessage().equals("no_existe_usuario"))
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);

            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

    }

    @GetMapping
    public ResponseEntity<List<UsuarioResponseDTO>> listarUsuarios() {
        List<UsuarioResponseDTO> usuarios = service.obtenerUsuarios();

        return new ResponseEntity<>(usuarios, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<UsuarioResponseDTO> modificarUsuario(@PathVariable Integer id, @Valid @RequestBody UsuarioRequestDTO requestDTO) {
        try {
            UsuarioResponseDTO responseDTO = service.actualizarUsuario(id, requestDTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);

        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarUsuario(@PathVariable Integer id) {
        service.eliminarUsuario(id);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/esAdmin/{id}")
    public ResponseEntity<UsuarioResponseDTO> modificarBool(@PathVariable Integer id) {
        try {
            UsuarioResponseDTO responseDTO = service.modificarBooleano(id);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);

        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }
}
