package com.proyecto.controller;

import com.proyecto.model.Simagrow_Espacio;
import com.proyecto.service.IEspacioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/espais")
public class EspacioController {

    @Autowired
    private IEspacioService service;

    @PostMapping
    public ResponseEntity<Simagrow_Espacio> crearEspacio(@RequestBody Simagrow_Espacio e) {
        Simagrow_Espacio simagrowEspacio = service.crearEspacio(e);

        return new ResponseEntity<>(simagrowEspacio, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Simagrow_Espacio>> obtenerEspacios() {
        List<Simagrow_Espacio> simagrowEspacios = service.obtenerEspacios();

        return new ResponseEntity<>(simagrowEspacios, HttpStatus.OK);
    }

    @PutMapping
    public ResponseEntity<Simagrow_Espacio> modificarEspacio(@RequestBody Simagrow_Espacio e) {
        Simagrow_Espacio simagrowEspacio = service.modificarEspacio(e);

        return new ResponseEntity<>(simagrowEspacio, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarEspacio(@PathVariable Integer id) {
        service.eliminarEspacio(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
