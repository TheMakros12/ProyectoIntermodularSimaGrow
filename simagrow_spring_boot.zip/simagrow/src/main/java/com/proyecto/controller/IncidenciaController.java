package com.proyecto.controller;

import com.proyecto.model.dto.IncidenciaRequestDTO;
import com.proyecto.model.dto.IncidenciaResponseDTO;
import com.proyecto.service.IIncidenciaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/incidencies")
public class IncidenciaController {

    @Autowired
    private IIncidenciaService service;

    @PostMapping
    public ResponseEntity<IncidenciaResponseDTO> crearIncidencia(@Valid @RequestBody IncidenciaRequestDTO requestDTO) {
        IncidenciaResponseDTO responseDTO = service.crearIncidencia(requestDTO);

        return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<IncidenciaResponseDTO>> obtenerIncidencias() {
        List<IncidenciaResponseDTO> responseDTOS = service.obtenerIncidencias();

        return new ResponseEntity<>(responseDTOS, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<IncidenciaResponseDTO> modificarIncidencia(@Valid @PathVariable Integer id, @RequestBody IncidenciaRequestDTO requestDTO) {
        try {
            IncidenciaResponseDTO responseDTO = service.modificarIncidencia(id, requestDTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);

        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarIncidencia(@PathVariable Integer id) {
        service.eliminarIndicencia(id);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/resuelta/{id}")
    public ResponseEntity<IncidenciaResponseDTO> cambiarEstado(@PathVariable Integer id) {
        try {
            IncidenciaResponseDTO responseDTO = service.cambiarEstado(id);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);

        } catch (Exception e) {
            if (e.getMessage().equals("incidencia_no_existe"))
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);

            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}
